﻿using AuthenticationExercise.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Security.Claims;
using System.Threading.Tasks;

namespace AuthenticationExercise.Controllers
{
	[ApiController]
	[Route("api/authentication")]
	[Authorize]
	public class AuthenticationController : Controller
	{
		private IAuthenticationService _authenticationService;

		public AuthenticationController(IAuthenticationService authenticationService)
		{
			_authenticationService = authenticationService;
		}

		[HttpPost]
		public async Task<IActionResult> Authenticate()
		{
			var userAccount = await _authenticationService.Authenticate(User);
			if (userAccount == null)
			{
				return NotFound();
			}
			return Ok();
		}
	}
}
