﻿using AuthenticationExercise.DataAccess;
using AuthenticationExercise.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace AuthenticationExercise.Services
{
	public interface IAuthenticationService
	{
		//Task<UserAccount> GetUserAccountByExternalId(string externalIdentifier);

		Task<UserAccount> Authenticate(ClaimsPrincipal claimsPrincipal);
	}

	public class AuthenticationService : IAuthenticationService
	{
		private readonly IUserAccountDao _userAccountDao;

		public AuthenticationService(IUserAccountDao userAccountDao)
		{
			_userAccountDao = userAccountDao;
		}

		public async Task<UserAccount> Authenticate(ClaimsPrincipal claimsPrincipal)
		{
			var externalIdentifier = claimsPrincipal.FindFirstValue(ClaimTypes.NameIdentifier);
			var userAccount = await _userAccountDao.FindByExternalIdentifier(externalIdentifier);
			if (userAccount == null)
			{
				userAccount = new UserAccount
				{
					Username = claimsPrincipal.FindFirstValue(ClaimTypes.Upn),
					Firstname = claimsPrincipal.FindFirstValue(ClaimTypes.GivenName),
					Lastname = claimsPrincipal.FindFirstValue(ClaimTypes.Surname),
					ExternalIdentifier = claimsPrincipal.FindFirstValue(ClaimTypes.NameIdentifier)
				};

				await _userAccountDao.Insert(userAccount);
			}
			return userAccount;
		}
	}
}
