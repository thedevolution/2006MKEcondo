﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuthenticationExercise.Dtos
{
	public class ActionResponse
	{
		public enum ActionResult
		{
			INSERTED, UPDATED, DELETED, ERROR
		}

		public ActionResult Result { get; set; }

		public int ActionId { get; set; }

		public string ErrorMessage { get; set; }
	}
}
