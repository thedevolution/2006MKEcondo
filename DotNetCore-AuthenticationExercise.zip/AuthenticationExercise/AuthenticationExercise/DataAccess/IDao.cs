﻿using AuthenticationExercise.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuthenticationExercise.DataAccess
{
	public interface IDao<Dto>
	{
		Task<Dto> FindById(int id);
		Task<IEnumerable<Dto>> FindAll();
		Task<ActionResponse> Insert(Dto dto);
		Task<ActionResponse> Delete(int id);
		Task<ActionResponse> Update(Dto dto);
	}
}
