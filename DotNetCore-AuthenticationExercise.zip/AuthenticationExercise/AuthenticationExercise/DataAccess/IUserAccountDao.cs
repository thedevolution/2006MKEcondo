﻿using AuthenticationExercise.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuthenticationExercise.DataAccess
{
	public interface IUserAccountDao : IDao<UserAccount>
	{
		Task<UserAccount> FindByExternalIdentifier(string externalIdentifier);
	}
}
