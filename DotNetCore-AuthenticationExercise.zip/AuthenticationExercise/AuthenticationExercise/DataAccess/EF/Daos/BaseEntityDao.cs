﻿using AuthenticationExercise.DataAccess.EF.Entities;
using AuthenticationExercise.Dtos;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuthenticationExercise.DataAccess.EF.Daos
{
	public abstract class BaseEntityDao<Dto, Entity> : IDao<Dto> where Entity : BaseEntity
	{
		protected readonly ApplicationDataContext _applicationDataContext;

		public BaseEntityDao(ApplicationDataContext applicationDataContext)
		{
			_applicationDataContext = applicationDataContext;
		}

		public async Task<ActionResponse> Delete(int id)
		{
			var toReturn = new ActionResponse
			{
				ActionId = id
			};
			var found = await FindEntityById(id);
			if (found != null)
			{
				_applicationDataContext.Set<Entity>().Remove(found);
				await _applicationDataContext.SaveChangesAsync();
			}
			toReturn.Result = ActionResponse.ActionResult.DELETED;

			return toReturn;
		}

		protected async Task<Entity> FindEntityById(int id)
		{
			return await _applicationDataContext.Set<Entity>().FindAsync(id);
		}

		public async Task<IEnumerable<Dto>> FindAll()
		{
			return await _applicationDataContext.Set<Entity>().Select(entity => MapToDto(entity)).ToListAsync();
		}

		public async Task<Dto> FindById(int id)
		{
			var found = await FindEntityById(id);
			return found != null ? MapToDto(found) : default(Dto);
		}

		public async Task<ActionResponse> Insert(Dto dto)
		{
			var toInsert = MapToEntity(dto);
			toInsert.DateCreated = DateTime.Now;
			toInsert.DateUpdated = DateTime.Now;
			_applicationDataContext.Set<Entity>().Add(toInsert);
			await _applicationDataContext.SaveChangesAsync();

			return new ActionResponse
			{
				ActionId = toInsert.Id,
				Result = ActionResponse.ActionResult.INSERTED
			};
		}

		public async Task<ActionResponse> Update(Dto dto)
		{
			var toUpdate = MapToEntity(dto);
			toUpdate.DateUpdated = DateTime.Now;
			_applicationDataContext.Entry(toUpdate).State = EntityState.Modified;
			await _applicationDataContext.SaveChangesAsync();
			return new ActionResponse
			{
				ActionId = toUpdate.Id,
				Result = ActionResponse.ActionResult.UPDATED
			};
		}

		protected Task ExecuteSaveChanges()
		{
			try
			{
				_applicationDataContext.SaveChangesAsync();
			}
			catch (Exception e)
			{

				throw e;
			}
			return null;
		}

		

		protected abstract Entity MapToEntity(Dto dto);

		protected abstract Dto MapToDto(Entity entity);
	}
}
