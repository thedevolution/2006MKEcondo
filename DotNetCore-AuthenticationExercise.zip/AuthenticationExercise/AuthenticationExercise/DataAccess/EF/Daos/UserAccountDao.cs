﻿using AuthenticationExercise.DataAccess.EF.Entities;
using AuthenticationExercise.Dtos;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuthenticationExercise.DataAccess.EF.Daos
{
	public class UserAccountDao : BaseEntityDao<UserAccount, UserAccountEntity>, IUserAccountDao
	{
		public UserAccountDao(ApplicationDataContext applicationDataContext) : base(applicationDataContext)
		{
		}

		public async Task<UserAccount> FindByExternalIdentifier(string externalIdentifier)
		{
			var query = from a in _applicationDataContext.UserAccounts
						where a.ExternalIdentifier == externalIdentifier
						select new UserAccount
						{
							Username = a.Username,
							Firstname = a.Firstname,
							Lastname = a.Lastname,
							ExternalIdentifier = a.ExternalIdentifier
						};
			try
			{
				return await query.FirstOrDefaultAsync<UserAccount>();
			}
			catch (Exception e)
			{

				throw e;
			}
		}

		protected override UserAccount MapToDto(UserAccountEntity entity)
		{
			return new UserAccount
			{
				Username = entity.Username,
				Firstname = entity.Firstname,
				Lastname = entity.Lastname,
				ExternalIdentifier = entity.ExternalIdentifier
			};
		}

		protected override UserAccountEntity MapToEntity(UserAccount dto)
		{
			return new UserAccountEntity
			{
				Username = dto.Username,
				Firstname = dto.Firstname,
				Lastname = dto.Lastname,
				ExternalIdentifier = dto.ExternalIdentifier
			};
		}
	}
}
