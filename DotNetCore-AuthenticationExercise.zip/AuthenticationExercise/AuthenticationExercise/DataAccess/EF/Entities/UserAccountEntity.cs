﻿using System.ComponentModel.DataAnnotations.Schema;

namespace AuthenticationExercise.DataAccess.EF.Entities
{
	[Table("USER_ACCOUNT")]
	public class UserAccountEntity : BaseEntity
	{
		public string Username { get; set; }

		public string Firstname { get; set; }

		public string Lastname { get; set; }

		public string ExternalIdentifier { get; set; }
	}
}
