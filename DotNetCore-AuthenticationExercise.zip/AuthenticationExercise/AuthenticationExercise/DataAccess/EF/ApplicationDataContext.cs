﻿using AuthenticationExercise.DataAccess.EF.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuthenticationExercise.DataAccess.EF
{
    public class ApplicationDataContext : DbContext
    {
        public ApplicationDataContext(DbContextOptions<ApplicationDataContext> options)
            : base(options)
        {
        }
        public DbSet<UserAccountEntity> UserAccounts { get; set; }
    }
}
