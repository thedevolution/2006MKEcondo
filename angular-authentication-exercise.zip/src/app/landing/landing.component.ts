import { Component, OnInit } from '@angular/core';
import { MsalService } from '@azure/msal-angular';
import { AuthenticationResult } from '@azure/msal-browser';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css']
})
export class LandingComponent implements OnInit {

  constructor(
    private authService: MsalService,
    private authenticationService: AuthenticationService) { }

  ngOnInit(): void {
    this.authService.handleRedirectObservable().subscribe({
      next: (result: AuthenticationResult) => {
        if (result) {
          this.authService.instance.setActiveAccount(result.account);
          alert('Token: ' + result.accessToken);
          this.authenticationService.authenticate();
        }
      },
      error: (error) => console.log(error),
    });
  }

  authenticate() : void {
    this.authenticationService.authenticate();
  }
}
