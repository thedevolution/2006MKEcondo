import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { catchError, map, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private http: HttpClient) { }

  authenticate(): void {
    alert(environment.baseUrl + '/api/authentication');
    this.http.post(environment.baseUrl + '/api/authentication', {}).pipe(
      tap(_ => console.log('fetched!!!!!!!!!!'))
    ).subscribe();
  }
}
